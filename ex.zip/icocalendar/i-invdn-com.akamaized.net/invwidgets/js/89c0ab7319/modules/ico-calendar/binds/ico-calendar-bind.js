fronter.bind('[id^="timeFrame_"]', ['$', 'window', '$ajax'], function($el, $, window, $ajax) {
    var $section = $('main');
    var currentUrl = new URL(location.href);
    $el.on('click', function () {
        var tabName = $el.attr('id');
        tabName = tabName.replace('timeFrame_', '');
        $('[id^="timeFrame_"]').removeClass('toggled');
        $el.addClass('toggled');
        var cols = currentUrl.searchParams.get("cols");
        var colQuery = cols ? '&cols='+cols : '';

        $ajax({
            url: '/ico-calendar?currentTab='+tabName+colQuery,
            type: 'GET',
        }).success(function (data) {
            //load new data
            var result = data;
            if (typeof data === 'string') {
                result = JSON.parse(data);
            }

            $section.empty().html(result.html);
            hideColumns();
        }).error(function (response) {
        });
    });
});
